<?php

defined('ABSPATH') OR exit;

require_once __DIR__.'/pre_get_posts.php';